import streamlit as st
import pandas as pd
import io
import re
import json
from typing import Tuple, Dict, Optional
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime

def detect_separator(file_content: str) -> str:
    """
    Detect the separator used in the CSV file by checking common separators
    """
    separators = ['|', ',', '\t']
    sample_lines = file_content.split('\n')[:5]  # Check first 5 lines
    
    separator_counts = {}
    for sep in separators:
        count = sum(line.count(sep) for line in sample_lines if line.strip())
        separator_counts[sep] = count
    
    # Return the separator with the highest count
    return max(separator_counts, key=separator_counts.get)

def clean_code(code: str) -> str:
    """
    Clean ICD code by removing dots, spaces and converting to uppercase
    """
    if pd.isna(code) or code is None:
        return ""
    
    # Convert to string, remove dots and spaces, convert to uppercase
    cleaned = str(code).replace('.', '').replace(' ', '').upper().strip()
    return cleaned

def load_database_file(uploaded_file) -> Tuple[Optional[pd.DataFrame], str]:
    """
    Load and process the ICD correspondence database file
    """
    try:
        # Read file content
        content = uploaded_file.read().decode('utf-8')
        separator = detect_separator(content)
        
        # Reset file pointer
        uploaded_file.seek(0)
        
        # Read CSV with detected separator
        df = pd.read_csv(uploaded_file, sep=separator)
        
        # Expected columns: TargetI9 (ICD-10), Flags (ICD-9), I9Name
        if len(df.columns) < 2:
            return None, "El archivo de base de datos debe tener al menos 2 columnas"
        
        # Rename columns for consistency
        df.columns = ['ICD10_DB', 'ICD9_DB'] + list(df.columns[2:])
        
        # Clean the codes
        df['ICD10_DB_CLEAN'] = df['ICD10_DB'].apply(clean_code)
        df['ICD9_DB_CLEAN'] = df['ICD9_DB'].apply(clean_code)
        
        return df, f"Base de datos cargada exitosamente. Separador detectado: '{separator}'. Registros: {len(df)}"
        
    except Exception as e:
        return None, f"Error al procesar el archivo de base de datos: {str(e)}"

def load_input_file(uploaded_file) -> Tuple[Optional[pd.DataFrame], str]:
    """
    Load and process the input file with ICD-10 codes
    """
    try:
        # Read file content
        content = uploaded_file.read().decode('utf-8')
        separator = detect_separator(content)
        
        # Reset file pointer
        uploaded_file.seek(0)
        
        # Read CSV with detected separator
        df = pd.read_csv(uploaded_file, sep=separator)
        
        # Look for ICD10 column (case insensitive)
        icd10_col = None
        for col in df.columns:
            if 'icd10' in col.lower():
                icd10_col = col
                break
        
        if icd10_col is None:
            return None, "No se encontró una columna llamada 'ICD10' en el archivo de entrada"
        
        # Rename column for consistency
        df = df.rename(columns={icd10_col: 'ICD10'})
        
        # Clean the codes
        df['ICD10_CLEAN'] = df['ICD10'].apply(clean_code)
        
        return df, f"Archivo de entrada cargado exitosamente. Separador detectado: '{separator}'. Códigos: {len(df)}"
        
    except Exception as e:
        return None, f"Error al procesar el archivo de entrada: {str(e)}"

def convert_codes(input_df: pd.DataFrame, database_df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, int]]:
    """
    Convert ICD-10 codes to ICD-9 using the database
    """
    # Create a mapping dictionary from the database
    # Use cleaned codes for matching
    db_mapping = dict(zip(database_df['ICD10_DB_CLEAN'], database_df['ICD9_DB']))
    
    results = []
    stats = {'found': 0, 'not_found': 0, 'total': 0}
    
    for _, row in input_df.iterrows():
        original_code = row['ICD10']
        clean_code = row['ICD10_CLEAN']
        
        # Look for exact match first
        if clean_code in db_mapping:
            icd9_code = db_mapping[clean_code]
            results.append({
                'ICD10': original_code,
                'ICD9': icd9_code
            })
            stats['found'] += 1
        else:
            results.append({
                'ICD10': original_code,
                'ICD9': 'NO_ENCONTRADO'
            })
            stats['not_found'] += 1
        
        stats['total'] += 1
    
    result_df = pd.DataFrame(results)
    return result_df, stats

def validate_icd_codes(input_df: pd.DataFrame) -> Tuple[pd.DataFrame, list]:
    """
    Validate ICD-10 code formats and provide suggestions for corrections
    """
    validation_issues = []
    
    # ICD-10 pattern: Letter followed by 2-3 digits, optionally followed by dot and more characters
    # Examples: A18.01, H40.50X2, F45.8
    icd10_pattern = r'^[A-Z]\d{2}\.?\d*[A-Z]?\d*$'
    
    for idx, row in input_df.iterrows():
        original_value = row['ICD10']
        
        # Check if empty or null BEFORE converting to string
        if pd.isna(original_value):
            validation_issues.append({
                'row': idx + 2,  # +2 for header and 0-indexing
                'code': 'NULL/NaN',
                'issue': 'Código vacío (NULL)',
                'suggestion': 'Eliminar esta fila o proporcionar un código válido'
            })
            continue
        
        # Now convert to string and check for whitespace-only
        code = str(original_value).strip()
        
        if not code or code == '':
            validation_issues.append({
                'row': idx + 2,
                'code': repr(original_value),
                'issue': 'Código vacío o solo espacios',
                'suggestion': 'Eliminar esta fila o proporcionar un código válido'
            })
            continue
        
        clean = clean_code(code)
        
        # Check if it starts with a letter
        if not clean or not re.match(r'^[A-Z]', clean):
            validation_issues.append({
                'row': idx + 2,
                'code': code,
                'issue': 'No comienza con una letra mayúscula',
                'suggestion': f'Debería comenzar con una letra (A-Z). Ejemplo: A{clean[1:] if len(clean) > 1 else "00"}'
            })
            continue
        
        # Check minimum length (letter + 2 digits)
        if len(clean) < 3:
            validation_issues.append({
                'row': idx + 2,
                'code': code,
                'issue': 'Código demasiado corto',
                'suggestion': 'Los códigos ICD-10 deben tener al menos 3 caracteres (ej: A18)'
            })
            continue
        
        # Check for invalid characters
        if not re.match(r'^[A-Z0-9\.]+$', code.upper()):
            invalid_chars = set(re.findall(r'[^A-Z0-9\.]', code.upper()))
            validation_issues.append({
                'row': idx + 2,
                'code': code,
                'issue': f'Contiene caracteres inválidos: {", ".join(invalid_chars)}',
                'suggestion': 'Solo se permiten letras, números y puntos'
            })
            continue
        
        # Validate against ICD-10 pattern
        if not re.match(icd10_pattern, clean):
            validation_issues.append({
                'row': idx + 2,
                'code': code,
                'issue': 'Formato ICD-10 incorrecto',
                'suggestion': 'El formato esperado es: Letra + 2-3 dígitos + opcional(punto + más caracteres). Ejemplo: A18.01'
            })
    
    # Create summary DataFrame
    if validation_issues:
        issues_df = pd.DataFrame(validation_issues)
    else:
        issues_df = pd.DataFrame()
    
    return issues_df, validation_issues

def create_visualizations(stats: Dict[str, int]):
    """
    Create visualization charts for conversion statistics
    """
    # Pie chart
    fig_pie = go.Figure(data=[go.Pie(
        labels=['Encontrados', 'No encontrados'],
        values=[stats['found'], stats['not_found']],
        marker=dict(colors=['#28a745', '#dc3545']),
        hole=0.4
    )])
    fig_pie.update_layout(
        title="Distribución de Conversiones",
        height=300,
        margin=dict(l=20, r=20, t=40, b=20)
    )
    
    # Bar chart
    fig_bar = go.Figure(data=[
        go.Bar(
            x=['Encontrados', 'No encontrados'],
            y=[stats['found'], stats['not_found']],
            marker=dict(color=['#28a745', '#dc3545']),
            text=[stats['found'], stats['not_found']],
            textposition='auto'
        )
    ])
    fig_bar.update_layout(
        title="Estadísticas de Conversión",
        xaxis_title="Estado",
        yaxis_title="Cantidad de códigos",
        height=300,
        margin=dict(l=20, r=20, t=40, b=20)
    )
    
    return fig_pie, fig_bar

def main():
    st.title("🏥 Convertidor de Códigos Médicos ICD-10 a ICD-9")
    st.markdown("---")
    
    # Initialize session state for conversion history
    if 'conversion_history' not in st.session_state:
        st.session_state.conversion_history = []
    
    # Sidebar with instructions
    with st.sidebar:
        st.header("📋 Instrucciones")
        st.markdown("""
        1. **Sube la base de datos** de correspondencias (archivo con equivalencias ICD-10 ↔ ICD-9)
        2. **Sube el archivo de entrada** con los códigos ICD-10 a convertir
        3. **Procesa** los archivos para generar las correspondencias
        4. **Descarga** el archivo resultante
        """)
        
        st.markdown("---")
        st.markdown("**Formatos soportados:**")
        st.markdown("- CSV con separadores: | , \\t")
        st.markdown("- Limpieza automática de códigos")
        st.markdown("- Detección automática de columnas")
        
        # Conversion history
        st.markdown("---")
        st.header("📚 Historial de Conversiones")
        
        if st.session_state.conversion_history:
            st.markdown(f"*{len(st.session_state.conversion_history)} conversión(es) en esta sesión*")
            
            for idx, conversion in enumerate(reversed(st.session_state.conversion_history)):
                with st.expander(f"Conversión {len(st.session_state.conversion_history) - idx} - {conversion['timestamp']}"):
                    st.write(f"**Total:** {conversion['stats']['total']} códigos")
                    st.write(f"**Encontrados:** {conversion['stats']['found']}")
                    st.write(f"**No encontrados:** {conversion['stats']['not_found']}")
                    
                    # Download from history
                    csv_buffer = io.StringIO()
                    conversion['result_df'].to_csv(csv_buffer, index=False)
                    st.download_button(
                        label="📥 Descargar (CSV)",
                        data=csv_buffer.getvalue(),
                        file_name=f"output_icd9_{conversion['timestamp'].replace(':', '-').replace(' ', '_')}.csv",
                        mime="text/csv",
                        key=f"download_history_{idx}"
                    )
        else:
            st.info("No hay conversiones en el historial")

    # Main content
    st.subheader("📊 Base de Datos de Correspondencias")
    database_file = st.file_uploader(
        "Sube el archivo de base de datos (ej: ICD_9_10_d_v1.1.csv)",
        type=['csv'],
        key='database_file',
        help="Archivo que contiene las equivalencias entre códigos ICD-10 e ICD-9"
    )
    
    if database_file:
        database_df, db_message = load_database_file(database_file)
        if database_df is not None:
            st.success(db_message)
            
            # Tab selection for viewing modes
            tab1, tab2 = st.tabs(["📋 Ver Tabla de Conversión", "📄 Convertir desde Archivo"])
            
            with tab1:
                st.markdown("### Tabla Completa de Conversiones ICD-10 a ICD-9")
                
                # Search functionality for the database
                search_db = st.text_input(
                    "🔍 Buscar en la base de datos",
                    placeholder="Buscar por código ICD-10 o ICD-9...",
                    help="Filtra la tabla de conversión",
                    key="search_db"
                )
                
                # Create display DataFrame with ICD10 and ICD9 columns
                display_df = database_df[['ICD10_DB', 'ICD9_DB']].copy()
                display_df.columns = ['ICD10', 'ICD9']
                
                # Filter if search query exists
                if search_db:
                    filtered_display = display_df[
                        display_df['ICD10'].str.contains(search_db, case=False, na=False) |
                        display_df['ICD9'].str.contains(search_db, case=False, na=False)
                    ]
                    st.info(f"Mostrando {len(filtered_display)} de {len(display_df)} conversiones")
                    st.dataframe(filtered_display, use_container_width=True, height=500)
                else:
                    st.dataframe(display_df, use_container_width=True, height=500)
                
                # Download the full conversion table
                st.subheader("📥 Descargar Tabla Completa")
                export_format_db = st.radio(
                    "Formato de exportación:",
                    ["CSV", "Excel", "JSON"],
                    horizontal=True,
                    key="export_db"
                )
                
                if export_format_db == "CSV":
                    csv_buffer = io.StringIO()
                    display_df.to_csv(csv_buffer, index=False)
                    file_data = csv_buffer.getvalue()
                    file_name = "conversiones_icd10_icd9.csv"
                    mime_type = "text/csv"
                elif export_format_db == "Excel":
                    excel_buffer = io.BytesIO()
                    with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                        display_df.to_excel(writer, index=False, sheet_name='Conversiones')
                    file_data = excel_buffer.getvalue()
                    file_name = "conversiones_icd10_icd9.xlsx"
                    mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                else:
                    json_data = display_df.to_json(orient='records', indent=2)
                    file_data = json_data
                    file_name = "conversiones_icd10_icd9.json"
                    mime_type = "application/json"
                
                st.download_button(
                    label=f"📥 Descargar {file_name}",
                    data=file_data,
                    file_name=file_name,
                    mime=mime_type,
                    use_container_width=True
                )
            
            with tab2:
                st.markdown("### Convertir Códigos desde Archivo CSV")
                input_file = st.file_uploader(
                    "Sube el archivo con códigos ICD-10 (ej: input_icd10.csv)",
                    type=['csv'],
                    key='input_file',
                    help="Archivo que contiene una columna 'ICD10' con los códigos a convertir"
                )
                
                if input_file:
                    input_df, input_message = load_input_file(input_file)
                    if input_df is not None:
                        st.success(input_message)
                        
                        # Validate ICD codes
                        issues_df, validation_issues = validate_icd_codes(input_df)
                        
                        if validation_issues:
                            st.warning(f"⚠️ Se encontraron {len(validation_issues)} problema(s) de formato en los códigos")
                            with st.expander("🔍 Ver problemas de validación", expanded=True):
                                st.dataframe(issues_df, use_container_width=True)
                                st.info("💡 Estos códigos se procesarán de todos modos, pero es posible que no se encuentren en la base de datos si tienen errores de formato.")
                        else:
                            st.success("✅ Todos los códigos tienen formato válido")
                        
                        with st.expander("👀 Vista previa del archivo de entrada"):
                            st.dataframe(input_df.head(10))
                    else:
                        st.error(input_message)
                        input_df = None
                
                # Process files (only in tab2)
                st.markdown("---")
                
                if 'input_df' in locals() and input_df is not None:
                    if st.button("🔄 Procesar Conversión", type="primary", use_container_width=True):
                        with st.spinner("Procesando conversión..."):
                            try:
                                # Convert codes
                                result_df, stats = convert_codes(input_df, database_df)
                                
                                # Save to history
                                st.session_state.conversion_history.append({
                                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                    'result_df': result_df.copy(),
                                    'stats': stats.copy()
                                })
                                
                                # Show results
                                st.success("✅ Conversión completada exitosamente!")
                                
                                # Statistics
                                col1, col2, col3 = st.columns(3)
                                with col1:
                                    st.metric("📊 Total de códigos", stats['total'])
                                with col2:
                                    st.metric("✅ Encontrados", stats['found'])
                                with col3:
                                    st.metric("❌ No encontrados", stats['not_found'])
                                
                                # Visualizations
                                if stats['total'] > 0:
                                    st.subheader("📊 Visualización de Estadísticas")
                                    chart_col1, chart_col2 = st.columns(2)
                                    fig_pie, fig_bar = create_visualizations(stats)
                                    with chart_col1:
                                        st.plotly_chart(fig_pie, use_container_width=True)
                                    with chart_col2:
                                        st.plotly_chart(fig_bar, use_container_width=True)
                                
                                # Results preview with search
                                st.subheader("📋 Resultados")
                                
                                # Search/filter functionality
                                search_query = st.text_input(
                                    "🔍 Buscar en resultados",
                                    placeholder="Buscar por código ICD-10 o ICD-9...",
                                    help="Filtra los resultados por código ICD-10 o ICD-9"
                                )
                                
                                # Filter results based on search query
                                if search_query:
                                    filtered_df = result_df[
                                        result_df['ICD10'].str.contains(search_query, case=False, na=False) |
                                        result_df['ICD9'].str.contains(search_query, case=False, na=False)
                                    ]
                                    st.info(f"Mostrando {len(filtered_df)} de {len(result_df)} resultados")
                                    st.dataframe(filtered_df, use_container_width=True)
                                else:
                                    st.dataframe(result_df, use_container_width=True)
                                
                                # Download section with multiple formats
                                st.subheader("📥 Descargar Resultados")
                                
                                export_format = st.radio(
                                    "Selecciona el formato de exportación:",
                                    ["CSV", "Excel", "JSON"],
                                    horizontal=True
                                )
                                
                                # Generate file based on selected format
                                if export_format == "CSV":
                                    csv_buffer = io.StringIO()
                                    result_df.to_csv(csv_buffer, index=False)
                                    file_data = csv_buffer.getvalue()
                                    file_name = "output_icd9.csv"
                                    mime_type = "text/csv"
                                elif export_format == "Excel":
                                    excel_buffer = io.BytesIO()
                                    with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                                        result_df.to_excel(writer, index=False, sheet_name='Conversiones')
                                    file_data = excel_buffer.getvalue()
                                    file_name = "output_icd9.xlsx"
                                    mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                else:  # JSON
                                    json_data = result_df.to_json(orient='records', indent=2)
                                    file_data = json_data
                                    file_name = "output_icd9.json"
                                    mime_type = "application/json"
                                
                                st.download_button(
                                    label=f"📥 Descargar {file_name}",
                                    data=file_data,
                                    file_name=file_name,
                                    mime=mime_type,
                                    use_container_width=True
                                )
                                
                                # Success rate
                                if stats['total'] > 0:
                                    success_rate = (stats['found'] / stats['total']) * 100
                                    st.info(f"📈 Tasa de éxito: {success_rate:.1f}% ({stats['found']}/{stats['total']} códigos encontrados)")
                                
                            except Exception as e:
                                st.error(f"❌ Error durante la conversión: {str(e)}")
        else:
            st.error(db_message)
            database_df = None
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: gray;'>
    🏥 Convertidor de Códigos Médicos ICD-10 a ICD-9<br>
    Herramienta para conversión automática de códigos médicos
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
