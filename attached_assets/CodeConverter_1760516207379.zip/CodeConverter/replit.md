# Overview

This is a Streamlit-based web application for processing and analyzing ICD (International Classification of Diseases) medical codes. The application provides functionality to:
- View complete ICD-10 to ICD-9 conversion tables directly in the browser
- Convert specific lists of ICD-10 codes from uploaded CSV files
- Search and filter conversion data
- Download results in multiple formats (CSV, Excel, JSON)
- Visualize conversion statistics with interactive charts
- Validate ICD code formats with suggestions for corrections
- Track conversion history within the session

It's designed for healthcare data analysts or medical coders who need to work with ICD code mappings and transformations.

# Recent Changes

**2024-10-14**: Added dual-mode interface with tabs:
- Tab 1: View complete conversion table directly from database with search and download capabilities
- Tab 2: Convert codes from uploaded CSV file (original functionality)
- Added visualization charts (pie and bar charts) for conversion statistics
- Implemented search/filtering in both modes
- Added multi-format export (CSV, Excel, JSON)
- Added session-based conversion history with re-download capability
- Implemented advanced ICD code validation with format checking and suggestions

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: Streamlit for web UI
  - **Rationale**: Streamlit provides a simple, Python-native way to build data applications without requiring frontend framework knowledge
  - **Pros**: Rapid development, automatic reactive updates, built-in components for file uploads and data display
  - **Cons**: Limited customization compared to full-stack frameworks, less control over UI/UX details

## Data Processing Layer
- **Core Library**: Pandas for data manipulation
  - **Problem**: Need to handle various CSV formats with different separators and clean inconsistent medical code formats
  - **Solution**: Custom separator detection algorithm and code cleaning functions
  - **Approach**: Auto-detect separators (pipe, comma, tab) by analyzing sample rows, then standardize codes by removing dots/spaces and uppercasing

## Visualization Components
- **Libraries**: Plotly (graph_objects and express modules)
  - **Rationale**: Interactive charts are essential for medical data analysis
  - **Pros**: Rich interactivity, professional visualizations, easy integration with Streamlit
  - **Alternatives Considered**: Matplotlib (less interactive), Altair (less feature-rich)

## Code Processing Design
- **Pattern**: Utility functions for data transformation
  - `detect_separator()`: Automatically identifies CSV delimiter by counting occurrences in sample lines
  - `clean_code()`: Standardizes ICD codes by removing formatting inconsistencies
  - `load_database_file()`: Orchestrates file loading with automatic separator detection

## Error Handling
- Return tuples with Optional types to handle file processing failures gracefully
- Defensive programming with null checks (pd.isna()) before string operations

# External Dependencies

## Core Python Libraries
- **streamlit**: Web application framework for data apps
- **pandas**: Data manipulation and CSV processing
- **plotly**: Interactive data visualization (graph_objects and express)

## Standard Library
- **io**: File-like object handling for uploaded files
- **re**: Regular expression support (imported but usage not shown in snippet)
- **json**: JSON data handling (imported but usage not shown in snippet)
- **typing**: Type hints for better code clarity (Tuple, Dict, Optional)
- **datetime**: Date and time handling

## File Format Support
- CSV files with multiple separator types (pipe |, comma, tab)
- UTF-8 encoded text files
- Automatic format detection without user configuration required

## Data Sources
- User-uploaded ICD correspondence database files
- No external APIs or databases in the current architecture
- File-based data processing workflow